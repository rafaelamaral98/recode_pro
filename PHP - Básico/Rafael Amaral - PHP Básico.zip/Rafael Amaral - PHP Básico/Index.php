<!DOCTYPE html>
<html lang="pt-br">
    
    <head>
        <meta charset="UTF-8">
        <title>Full Stack Eletro</title>
        <link rel="stylesheet" href="CSS/Estilo.css">
    </head>
    
    <body>   

        <?php
            include_once('Menu.html');
        ?>

        <br><br><br><br>

        <main>

            <h2>Seja Bem-Vindo (a)</h2>
            <p id="desconto">Aqui em nossa loja, programadores tem desconto nos produtos para sua casa!</p>

        </main>

        <br><br><br><br>
        <br><br><br><br>

        <footer id="copyright">

            <p id="formas_pagamento">Formas de Pagamento:</p>      
            <img src="Imagens/Formas de Pagamento.jpg" alt="Formas de Pagamento">

            <p>&copy; Rafael Amaral</p>

        </footer>

    </body>

</html>